
public class LockedMeMain {
	public static void main(String[] args) {
       
		System.out.println();
		System.out.println(" |********* WELCOME TO *********|");
		System.out.println(" |                              |");
		System.out.println(" |      ** LockedMe.com **      |");
		System.out.println(" |                              |");
		System.out.println(" | Developed by Prathmesh Ahire |");
		System.out.println(" ********************************");
		System.out.println();
        Menu menu = new Menu();
        menu.mainMenu();
    }
}
