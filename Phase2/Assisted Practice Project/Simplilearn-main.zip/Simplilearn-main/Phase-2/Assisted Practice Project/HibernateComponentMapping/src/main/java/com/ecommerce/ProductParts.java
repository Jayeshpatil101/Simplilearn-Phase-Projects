package com.ecommerce;

public class ProductParts {

        private String hdd;
        private String cpu;
        private String ram;
        
        public String getHdd() { return this.hdd;}
        public String getCpu() { return this.cpu;}
        public String getRam() { return this.ram;}
        
        public void setHdd(String value) { this.hdd= value;}
        public void setCpu(String value) { this.cpu= value;}
        public void setRam(String value) { this.ram= value;}
        
}
