# Phase5_CI-CD_Deployment_for_Springboot_Application
Command's

sudo yum update -y

sudo yum install -y httpd

sudo systemctl start httpd

sudo systemctl enable httpd

sudo yum install wget -y

java -version

sudo wget -O /etc/yum.repos.d/jenkins.repo/https://pkg.jenkins.io/redhat-stable/jenkins.repo

sudo rpm --import  https://pkg.jenkins.io/redhat-stable/jenkins.io.key

sudo yum upgrade

sudo amazon-linux-extras install epel -y

sudo yum update -y

sudo yum install jenkins java-1.8.0-openjdk-devel

wget https://my-springboot-web.s3.ap-south-1.amazonaws.com/my-spring-boot-web-aws-exe.jar

ls

java -jar  my-spring-boot-web-aws-exe.jar


open Broswer and run
--> localhost:9090
